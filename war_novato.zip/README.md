# Modo Novato – WAR Estruturado

Este projeto contém apenas o nível **Novato**, conforme solicitado.

## Funcionalidades
- Cadastro de 5 territórios
- Exibição do mapa completo
- Uso de struct e vetor estático
- Entrada de dados via terminal

## Compilação
```
gcc guerra.c -o guerra
```

## Execução
```
./guerra
```
