#include <stdio.h>
#include <string.h>

typedef struct {
    char nome[30];
    char cor[15];
    int tropas;
} Territorio;

int main() {
    Territorio vet[5];

    printf("=== Cadastro de Territórios (Modo Novato) ===\n");

    for (int i = 0; i < 5; i++) {
        printf("\n--- Território %d ---\n", i + 1);

        printf("Nome: ");
        scanf(" %29[^\n]", vet[i].nome);

        printf("Cor do Exército: ");
        scanf(" %14[^\n]", vet[i].cor);

        printf("Número de Tropas: ");
        scanf("%d", &vet[i].tropas);
    }

    printf("\n=== MAPA REGISTRADO ===\n");
    for (int i = 0; i < 5; i++) {
        printf("\nTerritório %d\n", i + 1);
        printf("Nome: %s\n", vet[i].nome);
        printf("Cor: %s\n", vet[i].cor);
        printf("Tropas: %d\n", vet[i].tropas);
    }

    return 0;
}